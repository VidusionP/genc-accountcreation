// 
// Import query-ui widgets/effects used in the theme here
//
import '@andxor/jquery-ui-touch-punch-fix';
import 'jquery-ui/ui/widgets/slider';

