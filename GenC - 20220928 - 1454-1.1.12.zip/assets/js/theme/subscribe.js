// Supermarket Theme: Implement for newsletter popup

import PageManager from '../page-manager';

export default class Subscribe extends PageManager {
    loaded(next) {
        next();
    }
}
